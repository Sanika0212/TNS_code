package OnlineShoppingEntities;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<ProductQuantityPair> cartItems;

    public ShoppingCart() {
        this.cartItems = new ArrayList<>();
    }

    public void addProduct(Product product, int quantity) {
        cartItems.add(new ProductQuantityPair(product, quantity));
    }

    public List<ProductQuantityPair> getCartItems() {
        return cartItems;
    }

    public void clearCart() {
        cartItems.clear();
    }
}
