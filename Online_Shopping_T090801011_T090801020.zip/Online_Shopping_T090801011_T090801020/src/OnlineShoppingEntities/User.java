package OnlineShoppingEntities;

public class User {
    private int userId;
    private String username;
    private String email;
    private String address;

    public User(int userId, String username, String email, String address) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.address = address;
    }

    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }
}
