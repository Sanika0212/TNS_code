package OnlineShoppingEntities;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private static int orderCounter = 1;
    private int orderId;
    private Customer customer;
    private List<ProductQuantityPair> products;
    private String status;

    public Order(Customer customer) {
        this.orderId = orderCounter++;
        this.customer = customer;
        this.products = new ArrayList<>();
        this.status = "Pending";
    }

    public void addProduct(Product product, int quantity) {
        products.add(new ProductQuantityPair(product, quantity));
    }

    public int getOrderId() {
        return orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<ProductQuantityPair> getProducts() {
        return products;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
