package OnlineShopping;

import OnlineShoppingServices.AdminService;
import OnlineShoppingServices.CustomerService;
import OnlineShoppingServices.OrderService;
import OnlineShoppingServices.ProductService;
import java.util.Scanner;

public class Online_Shopping {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductService productService = new ProductService();
        OrderService orderService = new OrderService();
        AdminService adminService = new AdminService(orderService);
        CustomerService customerService = new CustomerService();

        while (true) {
            System.out.println("\n===== Online Shopping System =====");
            System.out.println("1. Admin Menu");
            System.out.println("2. Customer Menu");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    adminService.adminMenu(scanner);
                    break;
                case 2:
                    customerService.customerMenu(scanner, adminService, orderService);
                    break;
                case 3:
                    System.out.println("Exiting... Thank you for using the system!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
