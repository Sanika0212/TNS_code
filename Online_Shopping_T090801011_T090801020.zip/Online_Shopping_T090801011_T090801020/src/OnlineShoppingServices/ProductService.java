package OnlineShoppingServices;

import OnlineShoppingEntities.Product;
import java.util.ArrayList;
import java.util.List;

public class ProductService {
    private List<Product> productList = new ArrayList<>();

    public void addProduct(int id, String name, double price, int stockQuantity) {
        Product product = new Product(id, name, price, stockQuantity);
        productList.add(product);
        System.out.println("Product added successfully: " + name);
    }

    public void removeProduct(int id) {
        boolean removed = productList.removeIf(p -> p.getProductId() == id);
        if (removed) {
            System.out.println("Product removed successfully!");
        } else {
            System.out.println("Product not found.");
        }
    }

    public List<Product> getAllProducts() {
        return productList;
    }

    public Product getProductById(int productId) {
        for (Product product : productList) {
            if (product.getProductId() == productId) {
                return product;
            }
        }
        return null;
    }

    public void viewAllProducts() {
        if (productList.isEmpty()) {
            System.out.println("No products available.");
            return;
        }

        System.out.println("\n--- Product List ---");
        for (Product product : productList) {
            System.out.println("ID: " + product.getProductId() + ", Name: " + product.getName() +
                    ", Price: $" + product.getPrice() + ", Stock: " + product.getStockQuantity());
        }
    }
}
