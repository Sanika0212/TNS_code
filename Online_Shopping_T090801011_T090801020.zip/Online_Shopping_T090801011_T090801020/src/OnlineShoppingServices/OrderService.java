package OnlineShoppingServices;

import OnlineShoppingEntities.Customer;
import OnlineShoppingEntities.Order;
import OnlineShoppingEntities.ProductQuantityPair;
import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private List<Order> orderList = new ArrayList<>();

    public void placeOrder(Customer customer, List<ProductQuantityPair> cartItems) {
        if (cartItems.isEmpty()) {
            System.out.println("Cart is empty! Add products before placing an order.");
            return;
        }

        Order newOrder = new Order(customer);
        for (ProductQuantityPair item : cartItems) {
            newOrder.addProduct(item.getProduct(), item.getQuantity());
        }

        newOrder.setStatus("Pending");
        orderList.add(newOrder);
        customer.addOrder(newOrder); // 🔥 FIX: Save the order inside the customer's account
        System.out.println("Order placed successfully with Order ID: " + newOrder.getOrderId());
    }

    public void updateOrderStatus(int orderId, String status) {
        for (Order order : orderList) {
            if (order.getOrderId() == orderId) {
                order.setStatus(status);
                System.out.println("Order ID " + orderId + " status updated to: " + status);
                return;
            }
        }
        System.out.println("Order not found!");
    }

    // 🔥 FIX: Added viewAllOrders() so Admin can see all orders
    public void viewAllOrders() {
        if (orderList.isEmpty()) {
            System.out.println("No orders available.");
            return;
        }

        System.out.println("\n--- Order List ---");
        for (Order order : orderList) {
            System.out.println("Order ID: " + order.getOrderId() + ", Customer: " + order.getCustomer().getUsername() +
                    ", Status: " + order.getStatus());
            for (ProductQuantityPair item : order.getProducts()) {
                System.out.println("  Product: " + item.getProduct().getName() + ", Quantity: " + item.getQuantity());
            }
        }
    }

    public void viewCustomerOrders(Customer customer) {
        List<Order> customerOrders = customer.getOrders();
        if (customerOrders.isEmpty()) {
            System.out.println("No orders found for " + customer.getUsername());
            return;
        }

        System.out.println("\n--- " + customer.getUsername() + "'s Orders ---");
        for (Order order : customerOrders) {
            System.out.println("Order ID: " + order.getOrderId() + ", Status: " + order.getStatus());
            for (ProductQuantityPair item : order.getProducts()) {
                System.out.println("  Product: " + item.getProduct().getName() + ", Quantity: " + item.getQuantity());
            }
        }
    }

    public List<Order> getOrders() {
        return orderList;
    }
}
