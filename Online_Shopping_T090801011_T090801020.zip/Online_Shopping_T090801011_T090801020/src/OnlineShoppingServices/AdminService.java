package OnlineShoppingServices;

import OnlineShoppingEntities.Admin;
import OnlineShoppingEntities.Order;
import OnlineShoppingEntities.Product;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AdminService {
    private List<Product> productList = new ArrayList<>();
    private List<Admin> adminList = new ArrayList<>();
    private OrderService orderService;

    public AdminService(OrderService orderService) {
        this.orderService = orderService;
        adminList.add(new Admin(1, "DefaultAdmin", "admin@example.com", "Admin Address")); // Default admin
    }

    public void adminMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n----- Admin Menu -----");
            System.out.println("1. Add Product");
            System.out.println("2. Remove Product");
            System.out.println("3. View Products");
            System.out.println("4. Create Admin");
            System.out.println("5. View Admins");
            System.out.println("6. Update Order Status");
            System.out.println("7. View Orders");
            System.out.println("8. Return to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addProduct(scanner);
                    break;
                case 2:
                    removeProduct(scanner);
                    break;
                case 3:
                    viewProducts();
                    break;
                case 4:
                    createAdmin(scanner);
                    break;
                case 5:
                    viewAdmins();
                    break;
                case 6:
                    updateOrderStatus(scanner);
                    break;
                case 7:
                    orderService.viewAllOrders();
                    break;
                case 8:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private void addProduct(Scanner scanner) {
        System.out.print("Enter Product ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Product Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter Stock Quantity: ");
        int stock = scanner.nextInt();

        productList.add(new Product(id, name, price, stock));
        System.out.println("Product added successfully!");
    }

    private void removeProduct(Scanner scanner) {
        if (productList.isEmpty()) {
            System.out.println("No products to remove.");
            return;
        }
        System.out.print("Enter Product ID to remove: ");
        int id = scanner.nextInt();

        boolean removed = productList.removeIf(p -> p.getProductId() == id);
        if (removed) {
            System.out.println("Product removed successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    public void viewProducts() {
        if (productList.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        System.out.println("\n--- Product List ---");
        for (Product p : productList) {
            System.out.println("ID: " + p.getProductId() + ", Name: " + p.getName() +
                    ", Price: $" + p.getPrice() + ", Stock: " + p.getStockQuantity());
        }
    }

    private void createAdmin(Scanner scanner) {
        System.out.print("Enter Admin ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Admin Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Admin Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Admin Address: ");
        String address = scanner.nextLine();

        adminList.add(new Admin(id, name, email, address));
        System.out.println("Admin created successfully!");
    }

    private void viewAdmins() {
        if (adminList.isEmpty()) {
            System.out.println("No admins available.");
            return;
        }
        System.out.println("\n--- Admin List ---");
        for (Admin admin : adminList) {
            System.out.println("ID: " + admin.getUserId() + ", Name: " + admin.getUsername() + ", Email: " + admin.getEmail());
        }
    }

    public void updateOrderStatus(Scanner scanner) {
        System.out.print("Enter Order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new status (Completed/Delivered/Cancelled): ");
        String status = scanner.nextLine();
        orderService.updateOrderStatus(orderId, status);
    }

    public List<Product> getProductList() {
        return productList;
    }
}
