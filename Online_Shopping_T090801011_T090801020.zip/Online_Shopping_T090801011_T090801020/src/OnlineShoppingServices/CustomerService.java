package OnlineShoppingServices;

import OnlineShoppingEntities.Customer;
import OnlineShoppingEntities.Product;
import OnlineShoppingEntities.ShoppingCart;
import java.util.Scanner;

public class CustomerService {
    private ShoppingCart cart = new ShoppingCart();

    public void customerMenu(Scanner scanner, AdminService adminService, OrderService orderService) {
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Address: ");
        String address = scanner.nextLine();

        Customer customer = new Customer(userId, username, email, address);

        while (true) {
            System.out.println("\n----- Customer Menu -----");
            System.out.println("1. View Products");
            System.out.println("2. Add Product to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Place Order");
            System.out.println("5. View My Orders"); // 🔥 FIX: Customers can now see their orders
            System.out.println("6. Return to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    adminService.viewProducts();
                    break;
                case 2:
                    addToCart(scanner, adminService);
                    break;
                case 3:
                    viewCart();
                    break;
                case 4:
                    placeOrder(customer, orderService);
                    break;
                case 5:
                    orderService.viewCustomerOrders(customer); // 🔥 FIX: Customers can see order status
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private void addToCart(Scanner scanner, AdminService adminService) {
        System.out.print("Enter Product ID to add: ");
        int productId = scanner.nextInt();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();

        for (Product product : adminService.getProductList()) {
            if (product.getProductId() == productId) {
                cart.addProduct(product, quantity);
                System.out.println(quantity + " " + product.getName() + "(s) added to cart.");
                return;
            }
        }
        System.out.println("Product not found!");
    }

    private void viewCart() {
        if (cart.getCartItems().isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            System.out.println("\n--- Shopping Cart ---");
            for (var item : cart.getCartItems()) {
                System.out.println("Product: " + item.getProduct().getName() + ", Quantity: " + item.getQuantity());
            }
        }
    }

    private void placeOrder(Customer customer, OrderService orderService) {
        if (cart.getCartItems().isEmpty()) {
            System.out.println("Cart is empty! Add products before placing an order.");
            return;
        }

        orderService.placeOrder(customer, cart.getCartItems());
        cart.clearCart();
        System.out.println("Order placed successfully!");
    }
}
